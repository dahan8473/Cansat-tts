/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tts;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;
import java.awt.event.*;  
import javax.swing.*;  

public class Tts {

    public static void main(String[] args) {

  JFrame f=new JFrame("Voice Synthesizer");
//initializes and sets up text fields for input
    JLabel text1 = new JLabel("Enter text"); 
    text1.setBounds(50,50,200,20); 

    final JTextField tf1=new JTextField(); 
    tf1.setBounds(50,75,350,100);   

/*
    JTextArea ta = new JTextArea(); 
    ta.setBounds(400,70,500,200 ); 

    final JTextField tfMain=new JTextField(); 
    tfMain.setBounds(400,70,500,200);   

//initializes button that makes story visible
    JButton story=new JButton("Show Story!");   
    story.setBounds(50,310,150,30);   
*/

/*
    story.addActionListener(new ActionListener() 
    {   

        public void actionPerformed(ActionEvent e){   
//inputs variables with user input from the text boxes
            String adv1 = tf1.getText(); 
            String num1 = tf2.getText(); 
            String adj1 = tf3.getText(); 
            String name = tf4.getText(); 
            String num2 = tf5.getText(); 
            String verb = tf6.getText(); 
//Main story frame
            ta.setText(" As Mr.Ahn " + adv1 + " walk towards you, you knew your life is coming to an end. " + 
                "\n \"Hey can I talk to you outside for a moment?\" " +
                "\n *Your knees buckle.*" +
                "\n Standing at "+ num1 + " feet tall, his " + adj1 + " eyes stares into your soul. " +
                "\n Hey " + name + " can you explain to me why you got " + num2 + " on this integral test? " +
                "\n his voice makes your whole body shiver" +
                "\n \"I am very dissapointed in you...\"" +
                "\n before you can react, he " + verb + " you..."   

        }   
    });   
        */
//add components to the main frame
    f.add(text1); 
    f.add(tf1);  

/*
    f.add(ta); 
    f.add(tfMain);

    f.add(story); 

*/
    f.setSize(1000,750);   

    f.setLayout(null);   

    f.setVisible(true);    
     /*
        Voice voice = VoiceManager.getInstance().getVoice("kevin16");
        
        Voice []voicelist = VoiceManager.getInstance().getVoices();
        for (Voice name : voicelist){
            System.out.println("# Voice: " + name.getName());

        }
        if(voice != null){
            voice.allocate();
            System.out.println("Voice Rate: " + voice.getRate());
            System.out.println("Voice Pitch: " + voice.getPitch());
            System.out.println("Voice Volume:" + voice.getVolume());
            boolean status = voice.speak("Hello world.");
            System.out.println("Status: " + status);
            voice.deallocate();
        }
        else{
            System.out.println("Error in getting names.");
        }
*/
    }
    
}
